#include "Board.h"
//#include "Block.h"

Board::Board(int w, int h) : height(h), width(w){
	cells = new Cell*[h];
	for(int i=0; i<h; i++){
		cells[i] = new Cell[w/2];
		for(int j=0; j<w/2; j++)
			cells[i][j] = VOID;
	}
	fulllines = 0;
	blockcount = 0;
}

Board::~Board(){

	for(int i=0; i<height; i++) delete[] cells[i];
	delete[] cells;

}

bool Board::insertBlock(){

	blockcount++;
	t_y = 2; t_x = 4; // 현재 왼쪽 아래

	if(cells[t_y][t_x] == VOID){
		cells[t_y-1][t_x] = O; // 왼쪽 위
		cells[t_y-1][t_x+1] = O; // 오른쪽 위
		cells[t_y][t_x+1] = O; // 오른쪽 아래
		cells[t_y][t_x] = O; // 왼쪽 아래
		return true;
	}
	else return false;
	

}

bool Board::moveBlockLeft(){

	// 현재 위치는 2,4 왼쪽 아래
	if(cells[t_y][t_x-1] == VOID && cells[t_y-1][t_x-1] == VOID){
		if(t_x>0){
			cells[t_y][t_x-1] = O; // 왼쪽 아래
			cells[t_y-1][t_x-1] = O; // 왼쪽 위
			cells[t_y-1][t_x+1] = VOID; //
			cells[t_y][t_x+1] = VOID; //
			t_x = t_x-1; // 현재 tx ty는 왼쪽 아래
			return true;
		}
		else return true;
	}
	else return true;
}

bool Board::moveBlockRight(){

	// 현재 위치는 2,4 왼쪽 아래
	if(cells[t_y][t_x+2] == VOID && cells[t_y-1][t_x+2] == VOID){
		if(t_x<width/2-1){
			cells[t_y-1][t_x+2] = O; // 오른쪽 위
			cells[t_y][t_x+2] = O; // 오른쪽 아래
			cells[t_y][t_x] = VOID; //
			cells[t_y-1][t_x] = VOID; //
			t_x = t_x+1; // 현재 tx ty는 왼쪽 아래
			return true;
		}
		else return true;
	}
	else return true;
}

bool Board::moveBlockDown(){


	// 현재 위치는 2,4 왼쪽 아래
	if(t_y == height-1) return false;
	if(cells[t_y+1][t_x] == VOID && cells[t_y+1][t_x+1] == VOID){
		if(t_y<height){
			cells[t_y-1][t_x] = VOID; 
			cells[t_y-1][t_x+1] = VOID; 
			cells[t_y+1][t_x] = O; //
			cells[t_y+1][t_x+1] = O; //
			t_y = t_y+1; // 현재 tx ty는 왼쪽 아래
			return true;
		}
		else return true;
	}
	else return false;
}

void Board::dropBlock(){

	// 원래 있던 값들 다 지운다
	cells[t_y][t_x] = VOID; // 왼쪽 아래
	cells[t_y][t_x+1] = VOID; // 오른쪽 아래
	cells[t_y-1][t_x] = VOID; // 왼쪽 위
	cells[t_y-1][t_x+1] = VOID; // 오른쪽 위

	// 현재 t_x좌표에서 가장 작은 t_y값을 가지는 t_y좌표를 찾는다
	while(cells[t_y][t_x] != O && cells[t_y][t_x+1] != O){
		t_y++;
		if(t_y == height -1){
			break;
		}
	}

	if(t_y==height-1){
			cells[t_y-1][t_x] = O;// 왼쪽위
			cells[t_y-1][t_x+1] = O;// 오른쪽 위
			cells[t_y][t_x] = O;// 왼쪽 아래
			cells[t_y][t_x+1] = O;// 오른쪽 아래
	}
	else{	
			cells[t_y-2][t_x] = O;// 왼쪽위
			cells[t_y-2][t_x+1] = O;// 오른쪽 위
			cells[t_y-1][t_x] = O;// 왼쪽 아래
			cells[t_y-1][t_x+1] = O;// 오른쪽 아래
	}
}

void Board::eraseBlock(){

	bool erase = true;

	// 줄이 채워지는 경우
	int k = 19;
	while(k>0){
		erase = true;
		// 하나라도 VOID일 경우 지우지 않는다
		for(int j=0; j<width/2+1; j++){ // cells 0부터 9까지
			if(cells[k][j] == VOID){ erase = false; break;}
		}
		// 줄을 지우는 경우, 먼저 지우는 줄을 Void로 만들고
		if(erase){
			fulllines++;
			for(int l=0; l< width/2+1; l++) cells[k][l] = VOID;
			
			Cell *tmp = cells[k];

			int a = k;
			// 지우는 줄의 윗 줄을 하나씩 내려준다
			while(a>1){
				cells[a] = cells[a-1];
				a--;
			}

			cells[a] = tmp;

			k=20; // 하나씩 내려주니까 다시 처음부터 체크하기위해 20으로
		}
		k--;
	}
}
