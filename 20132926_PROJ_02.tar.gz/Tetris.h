#ifndef _TETRIS_H_
#define _TETRIS_H_
#include "Pane.h"
#include "Board.h"
#include <fstream>
using namespace std;

class Tetris{
	static const int B_WIDTH = 18;
	static const int B_HEIGHT = 20;
	Pane *infoPane_, *helpPane_, *nextPane_, *boardPane_, *statPane_;
	Board b;

public:
	Tetris();	
	~Tetris();
	void play();
	void replay(ifstream &instream);
	void updateScreen();
};

#endif
