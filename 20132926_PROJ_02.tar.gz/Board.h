#ifndef _BOARD_H_
#define _BOARD_H_

//#include "Block.h"

enum Cell{VOID, I, O, L, J, S, Z, T};

class Board{
	friend class StatPane;
	friend class InfoPane;
	friend class BoardPane;
	friend class Block;

private:
	int height;
	int width;
	Cell **cells; // 블록을 그릴 2차원배열
	int t_x, t_y; 
	Cell curBlock; // 현재 블록을 나타내는 변수
	int fulllines;
	int blockcount;

public:
	Board(int w, int h);
	~Board();
	bool insertBlock();
	bool moveBlockLeft();
	bool moveBlockRight();
	bool moveBlockDown();
	void dropBlock();
	void eraseBlock();
};

#endif
