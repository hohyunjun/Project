#include <ncurses.h>
#include "Tetris.h"
#include "Pane.h"
#include "Board.h"

	Tetris::Tetris() : b(B_WIDTH, B_HEIGHT){
		initscr(); // curses mode로 터미널 초기화
		start_color(); // 색을 사용하기 위해 호출
		keypad(stdscr, TRUE);
		noecho();
		cbreak(); // 라인 버퍼링 비활성화
		refresh(); // refresh를 써줘야 화면에 출력된다

		// 각 Pane들의 좌표와 크기를 할당한다.
		infoPane_ = new InfoPane(1,1,25,5);
		helpPane_ = new HelpPane(1,6,25,12);
		nextPane_ = new NextPane(1,18,25,5);
		boardPane_ = new BoardPane(30,0,24,24);
		statPane_ = new StatPane(60,3,20,20);
	}

	Tetris::~Tetris(){
		delete infoPane_;
		delete helpPane_;
		delete nextPane_;
		delete boardPane_;
		delete statPane_;
		endwin(); // 최종적으로 curses 모드를 끝내주어야 한다.
	}

	void Tetris::play(){
		int input;
		bool gameOver = false;
		bool newBlock = false;
//		Block next = O;
		updateScreen();
		input = getch();


		while(1){ // 새로운 블록을 생성하는 반복문
			b.eraseBlock(); // 일단 꽉찬블록 다 지워주고
			gameOver = !b.insertBlock();
			updateScreen();
			if(gameOver){
				input = getch();
				break;
			}
			while(!newBlock){
				input = getch();
				switch(input){
					case KEY_LEFT:
						newBlock = !b.moveBlockLeft();
						break;
					case KEY_RIGHT:
						newBlock = !b.moveBlockRight();
						break;
					case KEY_DOWN:
						newBlock = !b.moveBlockDown();
						break;
					case ' ':
						b.dropBlock();
						newBlock = true;
						break;
				}
				updateScreen();
			}
			newBlock = false;
		}
	}

	void Tetris::replay(ifstream &instream){
		char input;
		bool gameOver = false;
		bool newBlock = false;
//		Block next = O;
		updateScreen();
		input = getch();


		while(1){ // 새로운 블록을 생성하는 반복문
			b.eraseBlock(); // 일단 꽉찬블록 다 지워주고
			if(gameOver){
				input = getch();
				break;
			}
			gameOver = !b.insertBlock();
			updateScreen();
			if(gameOver){
				input = getch();
				break;
			}
			while(!newBlock){
				instream >> input;
				switch(input){
					case 'l':
						newBlock = !b.moveBlockLeft();
						break;
					case 'r':
						newBlock = !b.moveBlockRight();
						break;
					case 'g':
						newBlock = !b.moveBlockDown();
						break;
					case 'd':
						b.dropBlock();
						newBlock = true;
						break;
					case 'q':
						newBlock = true;
						gameOver = true;
						break;
				}
				updateScreen();
			}
			newBlock = false;
		}
	}

	void Tetris::updateScreen(){
		((InfoPane *)infoPane_)->draw(b);
		((HelpPane *)helpPane_)->draw();
		((NextPane *)nextPane_)->draw();
		((BoardPane *)boardPane_)->draw(b);
		((StatPane *)statPane_)->draw(b);
	}


