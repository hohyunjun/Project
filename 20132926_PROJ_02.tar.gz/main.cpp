#include <ncurses.h>
#include <fstream>
#include "Tetris.h"
using namespace std;

int main(){
	
	Tetris t;
	ifstream instream;
	instream.open("input.txt");
	if(instream.fail()){
		t.play();
	}

	t.replay(instream);

	return 0;
}





