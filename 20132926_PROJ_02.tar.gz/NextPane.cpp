#include <ncurses.h>
#include "Pane.h"

	NextPane::NextPane(int x, int y, int w, int h) : Pane(x,y,w,h){}
	void NextPane::draw(){
		init_pair(4, COLOR_CYAN, COLOR_BLACK);
		wattron(win_, COLOR_PAIR(4));
		box(win_,0,0);
		mvwprintw(win_, 0,width_/2-5, "N E X T");
		wattroff(win_, COLOR_PAIR(4));
		wrefresh(win_);
	}




