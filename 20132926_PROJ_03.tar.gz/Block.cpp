#include "Block.h"

Block::Block():rotate(0), height(20), width(18){}
